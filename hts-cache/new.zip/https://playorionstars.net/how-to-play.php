<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/responsive.css">
    <title>How to play - Orion Stars</title>
    <style>
        body{
            background-color: #fff !important;
        }
        .main-menu ul li:nth-child(3) a:after {
        position: absolute;
        width: 100%;
        height: 2px;
        background: linear-gradient(to right, #FFAF38, #7C0FA9);
    /*box-shadow: 0 3px 6px #173620;*/
     
        left: 0;
        bottom: -5px;
        content: "";
       }
    </style>
</head>
<body>


<!-- header starts  -->
 <header class="main-header">
    <div class="main-header-container g-container g-flex">
         <!-- logo  -->
     <div class="logo">
        <a href="./">
            <img src="./media/logo.png" alt="">
        </a>
     </div>
     <div class="mobile-nav">
             <span></span>
             <span></span>
     </div>
     <!-- menu  -->
      <nav class="menu g-flex">
          <div class="close-menu">
              <i class="bi bi-x-lg"></i>
          </div>
        <div class="main-menu">
            <ul class="g-flex">
                <li><a href="./">Home</a></li>
                <li><a href="./games.php">Games</a></li>
                <li><a href="./how-to-play.php">How to Play</a></li>
                <li><a href="./contact-us.php">Contact us</a></li>
            </ul>
        </div>
        <!-- second menu  -->
        <div class="second-menu">
            <ul class="g-flex">
                <li><a href="http://web.orionstars.org/hot_play/orionstars_pc/" target="_blank">Sign In</a></li>
                <li><a href="https://www.facebook.com/OrionStarss77/" target="_blank">Sign Up</a></li>
             </ul>
        </div>
      </nav>
    </div>
 </header>
 
<!-- header ends  -->
<section class="how-to-play-hero">
    <div class="how-to-play-hero-container">
        <img src="./media/how-to-play-hero.png" alt="">
        <div class="how-to-play-hero-content">
            <div>
                <h1>Game On: From Noob to Pro!</h1>
                <p>Just starting out? No sweat! Our easy-to-follow guides and killer tips will turn you into a gaming legend. Learn the ropes, master epic moves, and climb the ranks like a true champ.
Attacks and seizes into breathtaking worlds, pimp out your character and take on other players with swagger and skill. 
</p>
            </div>
        </div>
    </div>
</section>

<section class="download-fb">
    <div class="download-fb-container g-container">
        <div class="download-fb-overlay"></div>
        <div class="download-fb-design1"></div>
        <div class="download-fb-design2"></div>
        <div class="download-content-wrapper">
            <h2>Download via Facebook</h2>
            <p>You can easily download Fire kirin through our official Facebook page. Follow the steps below to get started.</p>
            <a href="https://www.facebook.com/OrionStarss77/" target="_blank">Click Here</a>
        </div>
    </div>
</section>

<section class="play-steps-main">
    <div class="play-steps-container g-container">
        <img src="./media/step-line.png">
        <div class="play-steps-wrapper g-flex">
            <!-- 1 -->
             <div class="play-steps">
                <h4>Step 1</h4>
                <p>Visit Our Facebook Page</p>
             </div>
             <!-- 2 -->
             <div class="play-steps">
                <h4>Step 2</h4>
                <p>contact us on Facebook</p>
             </div>
              <!-- 3 -->
              <div class="play-steps">
                <h4>Step 3</h4>
                <p>Deposit and Redeem</p>
             </div>
               <!-- 4 -->
               <div class="play-steps">
                <h4>Step 4</h4>
                <p>Enjoy your game</p>
             </div>
                <!-- 5 -->
        </div>
    </div>
</section>
<section class="need-help">
    <div class="need-help-overlay"></div>
    <div class="need-help-container g-container">
        <h3>Need Help?</h3>
        <p>Got questions, or feedback, or just want to say hi? Hit us up! We love hearing from our community. Whether you need help with the game or want to share your epic wins, we’re here for you.  <br> <a>digitalmavericks@go777.onmicrosoft.com</a></p>
    </div>
</section>

<section class="exp-main how-to-play-exp">
        <div class="exp-container">
            <!-- <h4>Have An Unforgettable <br>Experience</h4>
            <p>Have an unforgettable experience and play now to <br>get attractive promos</p>
            <a href="">Get Started</a> -->
            <div class="exp-services">
                <h4>Our Services</h4>
                <div class="services-wrapper g-flex">
                    <!-- 1 -->
                     <div class="service-box">
                        <img src="./media/sevices-1.png" alt="">
                     </div>
                     <!-- 2 -->
                     <div class="service-box">
                        <img src="./media/sevices-2.png" alt="">
                     </div>
                      <!-- 3 -->
                      <div class="service-box">
                        <img src="./media/sevices-3.png" alt="">
                     </div>
                       <!-- 4 -->
                </div>
            </div>
        </div>
     </section>
     <section class="copyright">
        <div class="copyright-container g-flex g-container">
            <div class="copy1 copy">
              <p>http://play.firekirin.in all rights reseverd</p>
            </div>
            <div class="copy2 copy">
              <p>Privacy policy | Terms & Conditions</p>
            </div>
        </div>
     </section>

     <!-- footer starts here  -->
<script src="./js/app.js"></script>

<div class="messager">
    <a href="https://andedeveloper.in/orion-stars/games.php" target="_blank">
        <img src="./media/messanger.svg" alt="">
    </a>
</div>
<!-- footer ends here  --></body>
</html>