<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/responsive.css">
    <title>Games - Orion Stars</title>
    <style>
       .main-menu ul li:nth-child(2) a:after {
        position: absolute;
        width: 100%;
        height: 2px;
        background: linear-gradient(to right, #FFAF38, #7C0FA9);
    /*box-shadow: 0 3px 6px #173620;*/
        left: 0;
        bottom: -5px;
        content: "";
       }
       .games-filter-box ul {
           display: none;
       }
       .games-filter-box img {
           border-radius: 10px;
       }
    </style>
</head>
<body>



<!-- header starts  -->
 <header class="main-header">
    <div class="main-header-container g-container g-flex">
         <!-- logo  -->
     <div class="logo">
        <a href="./">
            <img src="./media/logo.png" alt="">
        </a>
     </div>
     <div class="mobile-nav">
             <span></span>
             <span></span>
     </div>
     <!-- menu  -->
      <nav class="menu g-flex">
          <div class="close-menu">
              <i class="bi bi-x-lg"></i>
          </div>
        <div class="main-menu">
            <ul class="g-flex">
                <li><a href="./">Home</a></li>
                <li><a href="./games.php">Games</a></li>
                <li><a href="./how-to-play.php">How to Play</a></li>
                <li><a href="./contact-us.php">Contact us</a></li>
            </ul>
        </div>
        <!-- second menu  -->
        <div class="second-menu">
            <ul class="g-flex">
                <li><a href="http://web.orionstars.org/hot_play/orionstars_pc/" target="_blank">Sign In</a></li>
                <li><a href="https://www.facebook.com/OrionStarss77/" target="_blank">Sign Up</a></li>
             </ul>
        </div>
      </nav>
    </div>
 </header>
 
<!-- header ends  -->
<section class="games-hero">
  <div class="games-hero-container">
     <img src="./media/games-hero.png" alt="">
     <div class="games-hero-content">
      <div>
        <h1>Get ready to dominate!</h1>
        <p>From heart-pounding battles to mind-blowing quests, these games are your ticket to endless fun and adventure. Explore insane environments, trick out your character, and go head-to-head with other players with confidence.</p>
      </div>
      </div>
  </div>
</section>

<section class="games-main-filter">
   <div class="games-main-filter-container g-container">
      <ul class="g-flex">
        <li class="active"><b></b><span><img src="./media/all-games-icon.png" alt=""></span><strong>All Games</strong></li>
        <li><b></b><span><img src="./media/popular-game-icon.png" alt=""></span><strong>Popular</strong></li>
        <li><b></b><span><img src="./media/new-game-icon.png" alt=""></span><strong>New</strong></li>
        <li><b></b><span><img src="./media/coming-soon-game-icon.png" alt=""></span><strong>Coming Soon</strong></li>
      </ul>
   </div>
</section>

<!-- games  -->
<section class="games-filter-body">
   <div class="games-filter-body-container g-container">
    <div class="games-filter-body-wrapper">
       <!-- 1 -->
        <div class="games-filter-box first-game-box active">
         
                 <div class="games-filter-box-img  g-flex">
                
                   

           </div>
        </div>
       <!-- 2 -->

       <div class="games-filter-box second-game-box">
           
                 <div class="games-filter-box-img  g-flex">
                    
                    
                
           </div>
        </div>

       <!-- 3 -->
       <div class="games-filter-box third-game-box">
           
                 <div class="games-filter-box-img g-flex">

           </div>
        </div>



       <!-- 4 -->
       <div class="games-filter-box four-game-box">
           
                 <div class="games-filter-box-img g-flex">
                 </div>
        </div>

        
       <!-- 5 -->
       <!-- 6 -->
    </div>
   </div>
</section>

<!-- screenshots  -->
 <section class="games-screenshots">
  <h4>Game Screenshots</h4>
   <div class="games-screenshots-container g-flex">
      <!-- 1 -->
       <div class="games-screenshot-box">
         <img src="./media/screenshot-1.png" alt="">
       </div>
       <!-- 2 -->
       <div class="games-screenshot-box">
         <img src="./media/screenshot-2.png" alt="">
       </div>
        <!-- 3 -->
        <div class="games-screenshot-box">
         <img src="./media/screenshot-3.png" alt="">
       </div>
         <!-- 4 -->
         <div class="games-screenshot-box">
         <img src="./media/screenshot-4.png" alt="">
       </div>
          <!-- 5 -->
   </div>
 </section>

 <section class="exp-main games-exp">
        <div class="exp-container">
            <h4>Ready to join the ranks of <br>the ultimate warriors? </h4>
            <p>Have an unforgettable experience and play now to <br>get attractive promos</p>
            <a href="">Get Started</a>
            <div class="exp-services">
                <h4>Our Services</h4>
                <div class="services-wrapper g-flex">
                    <!-- 1 -->
                     <div class="service-box">
                        <img src="./media/sevices-1.png" alt="">
                     </div>
                     <!-- 2 -->
                     <div class="service-box">
                        <img src="./media/sevices-2.png" alt="">
                     </div>
                      <!-- 3 -->
                      <div class="service-box">
                        <img src="./media/sevices-3.png" alt="">
                     </div>
                       <!-- 4 -->
                </div>
            </div>
        </div>
     </section>
     <section class="copyright">
        <div class="copyright-container g-flex g-container">
            <div class="copy1 copy">
              <p>http://play.firekirin.in all rights reseverd</p>
            </div>
            <div class="copy2 copy">
              <p>Privacy policy | Terms & Conditions</p>
            </div>
        </div>
     </section>
<!-- footer starts here  -->
<script src="./js/app.js"></script>

<div class="messager">
    <a href="https://andedeveloper.in/orion-stars/games.php" target="_blank">
        <img src="./media/messanger.svg" alt="">
    </a>
</div>
<!-- footer ends here  -->    
</body>
</html>