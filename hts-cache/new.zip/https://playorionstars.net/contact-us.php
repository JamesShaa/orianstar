<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="./css/styles.css">
    <link rel="stylesheet" href="./css/responsive.css">
    <title>Contact us - Orion Stars</title>
    <style>
       body {
        background-color: #fff !important;
       }
       .main-menu ul li:nth-child(4) a:after {
        position: absolute;
        width: 100%;
        height: 2px;
        background: linear-gradient(to right, #FFAF38, #7C0FA9);
    /*box-shadow: 0 3px 6px #173620;*/
        left: 0;
        bottom: -5px;
        content: "";
       }
       form input, form textarea {
           color: #fff;
       }
    </style>
</head>
<body>


<!-- header starts  -->
 <header class="main-header">
    <div class="main-header-container g-container g-flex">
         <!-- logo  -->
     <div class="logo">
        <a href="./">
            <img src="./media/logo.png" alt="">
        </a>
     </div>
     <div class="mobile-nav">
             <span></span>
             <span></span>
     </div>
     <!-- menu  -->
      <nav class="menu g-flex">
          <div class="close-menu">
              <i class="bi bi-x-lg"></i>
          </div>
        <div class="main-menu">
            <ul class="g-flex">
                <li><a href="./">Home</a></li>
                <li><a href="./games.php">Games</a></li>
                <li><a href="./how-to-play.php">How to Play</a></li>
                <li><a href="./contact-us.php">Contact us</a></li>
            </ul>
        </div>
        <!-- second menu  -->
        <div class="second-menu">
            <ul class="g-flex">
                <li><a href="http://web.orionstars.org/hot_play/orionstars_pc/" target="_blank">Sign In</a></li>
                <li><a href="https://www.facebook.com/OrionStarss77/" target="_blank">Sign Up</a></li>
             </ul>
        </div>
      </nav>
    </div>
 </header>
 
<!-- header ends  -->
<section class="contact-hero">
   <div class="contact-hero-container">
     <img src="./media/contact-hero.png" alt="">
     <div class="contact-hero-content">
        <h1>CONTACT US</h1>
        <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, <br>sed diam nonumy eirmod tempor invidunt ut labore</p>
     </div>
   </div>
</section>

<section class="faq-main">
   <div class="faq-overlay"></div>
    <div class="faq-container g-container">
        <h3>FAQ (FREQUENTLY ASKED QUESTIONS)</h3>
        <div class="faq-wrapper desk-faq g-flex">
          <!-- questions  -->
          
        <div class="faq-que">
           <ul>
            <li class="active">Can I play without downloading the app? </li>
            <li>How to create an account and reload?</li>
            <li>I have a problem with my agent and cashout related concerns. Can you help?</li>
            <li>I want to become an agent?</li>
            <li>where can i download the app?</li>
           </ul>
        </div>
        <!-- answers  -->
         <div class="faq-answers">
            <!-- 1 -->
             <div class="faq-ans active">
                <p>Currently, we exclusively offer our gaming experience through our app. However, we are actively working on expanding our accessibility options to provide you with alternative ways to enjoy our platform without the need for a download.</p>
                <div class="faq-ans-design"></div>
             </div>
             <!-- 2 -->
             <div class="faq-ans">
                <p>Simply reach out to us by sending a message on our Official Facebook pages.
                 <br>
                  Our dedicated agents are ready to assist you through the process, ensuring a seamless experience for account creation and reloading.</p>
                <div class="faq-ans-design"></div>
             </div>
              <!-- 3 -->
              <div class="faq-ans">
               <p>We can only provide assistance for issues related to accounts created under our official pages. For concerns with accounts or interactions initiated elsewhere, we recommend reaching out directly to the respective agent or platform involved.</p>
                <div class="faq-ans-design"></div>
              </div>
               <!-- 4 -->
              <div class="faq-ans">
               <p>If you’re interested in joining our team as an agent, please send a message to our official Facebook account.
                <br>
               We’ll get back to you promptly with all the details you need to kick-start your journey with us.</p>
                <div class="faq-ans-design"></div>
              </div>
                <!-- 5 -->
                <div class="faq-ans">
                    <p>To download the app, please click on the following link: https://www.facebook.com/OrionStarss77/ If you encounter issues or have further questions, feel free to reach out to our support team for assistance.</p>
                    <div class="faq-ans-design"></div>
                </div>
                 <!-- 6 -->
         </div>
        </div>


    <!--mobile faq-->

<section class="mobile-faq">
    <div class="mobile-faq-container">
        <ul>
            <li class="active"><span>Can I play without downloading the app?</span> <i class="bi bi-plus-lg"></i></li>
             <!-- 1 -->
             <div class="mobile-faq-ans active">
                <p>Currently, we exclusively offer our gaming experience through our app. However, we are actively working on expanding our accessibility options to provide you with alternative ways to enjoy our platform without the need for a download.</p>
                <div class="faq-ans-design"></div>
             </div>
            <li><span>How to create an account and reload?</span> <i class="bi bi-plus-lg"></i></li>
            <!-- 2 -->
             <div class="mobile-faq-ans">
                <p>Simply reach out to us by sending a message on our Official Facebook pages.
                 <br>
                  Our dedicated agents are ready to assist you through the process, ensuring a seamless experience for account creation and reloading.</p>
                <div class="faq-ans-design"></div>
             </div>
            <li><span>I have a problem with my agent and cashout related concerns. Can you help?</span> <i class="bi bi-plus-lg"></i></li>
            <!-- 3 -->
              <div class="mobile-faq-ans">
               <p>We can only provide assistance for issues related to accounts created under our official pages. For concerns with accounts or interactions initiated elsewhere, we recommend reaching out directly to the respective agent or platform involved.</p>
                <div class="faq-ans-design"></div>
              </div>
            <li><span>I want to become an agent?</span> <i class="bi bi-plus-lg"></i></li>
             <!-- 4 -->
              <div class="mobile-faq-ans">
               <p>If you’re interested in joining our team as an agent, please send a message to our official Facebook account.
                <br>
               We’ll get back to you promptly with all the details you need to kick-start your journey with us.</p>
                <div class="faq-ans-design"></div>
              </div>
            <li><span>where can i download the app?</span> <i class="bi bi-plus-lg"></i></li>
            <!-- 5 -->
                <div class="mobile-faq-ans">
                    <p>To download the app, please click on the following link: https://www.facebook.com/OrionStarss77/ If you encounter issues or have further questions, feel free to reach out to our support team for assistance.</p>
                    <div class="faq-ans-design"></div>
                </div>
           </ul>
    </div>
</section>
<!--mobile faq completed -->


    </div>
</section>


<section class="contact-mail">
   <div class="contact-mail-container">
      <a href=""><i class="bi bi-envelope"></i> digitalmavericks@go777onmicrosoft.com</a>
   </div>
</section>

<section class="contact-form-main">
   <div class="contact-form-overlay"></div>
   <div class="contact-form-design"></div>
   <div class="contact-form-main-container g-container g-flex">
         <!-- left  -->
          <div class="contact-form-left">
             <div></div>
             <h3>LET'S GET IN TOUCH</h3>
             <p>Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy</p>
          </div>
          <!-- right  -->
           <div class="contact-form-right">
                <form action="contact-mail.php" method="POST" onsubmit="return validateForm()">
                    <input type="text" name="firstname" placeholder="FIRST NAME..." required>
                    <input type="text" name="lastname" placeholder="LAST NAME..." required>
                    <input type="email" name="email" placeholder="YOUR MAIL..." required>
                    <input type="text" id="mobile" name="mobile" placeholder="YOUR PHONE..." maxlength="10" minlength="10" required>
                    <textarea name="message" id="" placeholder="YOUR MESSAGE" required></textarea>
                    <input type="submit" value="SEND MESSAGE" class="submit-btn">
                </form>
           </div>
   </div>


   <section class="exp-main">
        <div class="exp-container">
            
            <div class="exp-services">
                <h4>Our Services</h4>
                <div class="services-wrapper g-flex">
                    <!-- 1 -->
                     <div class="service-box">
                        <img src="./media/sevices-1.png" alt="">
                     </div>
                     <!-- 2 -->
                     <div class="service-box">
                        <img src="./media/sevices-2.png" alt="">
                     </div>
                      <!-- 3 -->
                      <div class="service-box">
                        <img src="./media/sevices-3.png" alt="">
                     </div>
                       <!-- 4 -->
                </div>
            </div>
        </div>
     </section>
     <section class="copyright">
        <div class="copyright-container g-flex g-container">
            <div class="copy1 copy">
              <p>http://play.firekirin.in all rights reseverd</p>
            </div>
            <div class="copy2 copy">
              <p>Privacy policy | Terms & Conditions</p>
            </div>
        </div>
     </section>


</section>
<script>
    function validateForm() {
            const mobileInput = document.getElementById("mobile");
            const mobileValue = mobileInput.value;

            if (mobileValue.length !== 10 || isNaN(mobileValue)) {
                alert("Please enter a valid 10-digit mobile number.");
                return false;
            }
            return true;
        }
</script>

<!-- footer starts here  -->
<script src="./js/app.js"></script>

<div class="messager">
    <a href="https://andedeveloper.in/orion-stars/games.php" target="_blank">
        <img src="./media/messanger.svg" alt="">
    </a>
</div>
<!-- footer ends here  -->
</body>
</html>